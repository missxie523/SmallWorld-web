import React from 'react';

export class Home extends React.Component {
  render() {
    return (
      <div>this is home</div>
    );
  }
}
